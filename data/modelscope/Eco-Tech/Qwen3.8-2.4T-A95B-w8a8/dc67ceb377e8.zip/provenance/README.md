---
license: other
license_name: qwen3.8-max
license_link: LICENSE
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - Qwen/Qwen3.8-2.4T-A95B-FP8
base_model_relation: quantized
---
# Qwen3.8-2.4T-A95B-w8a8

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3.8-2.4T-A95B-FP8 |
| 原始模型链接  | [ Qwen/Qwen3.8-2.4T-A95B-FP8 ](https://www.modelscope.cn/models/Qwen/Qwen3.8-2.4T-A95B-FP8) |
| msmodelslim 仓库 | https://gitcode.com/joejoezhou/msmodelslim/tree/feature/qwen3_8-adapter |
| msmodelslim commit id | 4150b229077c3f1e31ca391d1ab6c2ec48d8936e |


## 2 量化脚本：

```shell
pip install transformers==5.14.0

msmodelslim quant --model_type Qwen3.8-2.4T-A95B-FP8 \
  --quant_type w8a8 \
  --model_path weight/Qwen3.8-2.4T-A95B-FP8 \
  --save_path weight/Qwen3.8-2.4T-A95B-w8a8 \
  --device npu:0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
```

## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|:------:|
| Qwen3.8-2.4T-A95B-w8a8 | w8a8 | GPQA | 91.92 | 92.6 |

* 使用`aisbench`，输出上限64k，8并发。精度存在波动，建议多次测试。