---
license: Apache License 2.0
tasks:
  - text-to-video-synthesis
frameworks: PyTorch
base_model:
  - Wan-AI/Wan2.2-T2V-A14B-Diffusers
base_model_relation: quantized
---
# Wan2.2-T2V-A14B-Diffusers-w8a8

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Wan2.2-T2V-A14B-Diffusers |
| 原始模型链接  | [Wan2.2-T2V-A14B-Diffusers](https://huggingface.co/Wan-AI/Wan2.2-T2V-A14B-Diffusers) |
| 精度测试机型  | Atlas 800T A3 1台|
| 精度测试平台  | sglang |
| 版本  | sglang 0.5.9|
| 链接  | https://github.com/sgl-project/sglang/pull/17996 |


## 2 量化命令：

WIP

## 3 精度测试结果

WIP