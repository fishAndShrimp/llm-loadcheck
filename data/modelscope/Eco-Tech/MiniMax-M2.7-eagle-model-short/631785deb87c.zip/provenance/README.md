---
frameworks: PyTorch
license: Apache License 2.0
tags: []
tasks:
- text-generation

#model-type:
##如 gpt、phi、llama、chatglm、baichuan 等
#- gpt

#domain:
##如 nlp、cv、audio、multi-modal
#- nlp

#language:
##语言代码列表 https://help.aliyun.com/document_detail/215387.html?spm=a2c4g.11186623.0.0.9f8d7467kni6Aa
#- cn

#metrics:
##如 CIDEr、Blue、ROUGE 等
#- CIDEr

#tags:
##各种自定义，包括 pretrained、fine-tuned、instruction-tuned、RL-tuned 等训练方法和其他
#- pretrained

#tools:
##如 vllm、fastchat、llamacpp、AdaSeq 等
#- vllm
base_model:
  - MiniMax/MiniMax-M2.7
  - Eco-Tech/MiniMax-M2.7-w8a8-QuaRot
---
# Eco-Tech/MiniMax-M2.7-eagle-model-short

## Model Overview
- **Verifier:** MiniMax/MiniMax-M2.7
- **Speculative Decoding Algorithm:** EAGLE-3
- **Model Architecture:** Eagle3Speculator
- **Release Date:** 04/06/2026
- **Version:** 0.5.0
- **Model Developers:** mindstudio

This is a speculator model designed for use with [MiniMax/MiniMax-M2.7](https://www.modelscope.cn/models/MiniMax/MiniMax-M2.7), based on the [EAGLE-3](https://arxiv.org/abs/2503.01840) speculative decoding algorithm.
This model should be used with the [MiniMax/MiniMax-M2.7](https://www.modelscope.cn/models/MiniMax/MiniMax-M2.7) chat template, specifically through the `v1/chat/completions` endpoint.


## Use with vLLM

```bash
  --speculative-config '{
    "model": "Eco-Tech/MiniMax-M2.7-eagle-model-short",
    "num_speculative_tokens": 3,
    "method": "eagle3"
  }'
```

## Evaluations

<h3>Acceptance lengths</h3>
<table>
  <thead>
    <tr>
      <th>Dataset</th>
      <th>gsm8k</th>
      <th>HumanEval</th>
      <th>aime2025</th>
      <th>中文</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Acceptance lengths</td>
      <td>3.27</td>
      <td>2.91</td>
      <td>2.72</td>
      <td>2.61</td>
    </tr>
  </tbody>
</table>

