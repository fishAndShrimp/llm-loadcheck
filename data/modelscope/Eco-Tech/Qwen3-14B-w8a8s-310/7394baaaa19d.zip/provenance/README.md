---
license: Apache License 2.0
frameworks: PyTorch
base_model_relation: quantized

base_model:
  - Qwen/Qwen3-14B
tasks:
  - text-generation
---
# Qwen3-14B-w8a8s-310

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3-14B |
| 原始模型链接  | [Qwen/Qwen3-14B](https://huggingface.co/Qwen/Qwen3-8B) |
| msmodelslim commit id  | 6a860e4a7b48b4573a8aeeaa12123d2bbc9ec9b8 |
| msmodelslim 操作指引  | [Readme](https://gitcode.com/Ascend/msmodelslim/blob/master/example/Qwen/README.md) |
| 精度测试机型  | Atlas 300I DUO|
| 精度测试平台  | docker MindIE 镜像 |
| 版本  | MindIE 2.3.0 |


## 2 量化命令：
### 模型稀疏量化
```Shell
msmodelslim quant --model_path {浮点权重路径} --save_path {W8A8量化权重路径} --device npu --model_type Qwen3-8B --quant_type w8a8s --trust_remote_code True
```


## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 浮点精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3-14B-w8a8s-310 | w8a8s | BoolQ |88.41 | 89.27 |
| Qwen3-14B-w8a8s-310 | w8a8s | CEval |82.17 | 83.06 |
| Qwen3-14B-w8a8s-310 | w8a8s | GSM8K |94.31 | 94.84 |
* 精度数据来自于非深度思考模式的推理结果
