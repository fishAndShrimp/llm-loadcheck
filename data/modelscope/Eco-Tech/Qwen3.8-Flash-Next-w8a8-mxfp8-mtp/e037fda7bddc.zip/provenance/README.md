---
frameworks:
  - PyTorch
license: other
license_name: qwen-community-1.0
license_link: https://www.modelscope.cn/models/Qwen/Qwen3.8-Flash-Next/file/view/master/LICENSE
base_model_relation: quantized
base_model:
  - Qwen/Qwen3.8-Flash-Next
tasks:
  - image-text-to-text
pipeline_tag: image-text-to-text
---

# Qwen3.8-Flash-Next-w8a8-mxfp8-mtp

## 1. 基本信息

| 项目 | 信息 |
|:------:|:------:|
| 原始模型名 | Qwen3.8-Flash-Next |
| 原始模型链接 | [Qwen/Qwen3.8-Flash-Next](https://www.modelscope.cn/models/Qwen/Qwen3.8-Flash-Next) |
| msmodelslim commit id | a3664d45aef26c9ccd7fb4884a6c2b2c2ee1456a |
| 精度测试机型 | 未测试 |
| 精度测试平台 | 未测试 |
| 版本 | - |
| 链接 | - |

## 2. 量化脚本

量化使用 `master-qwen38` 分支。该分支已适配 Qwen3.8-Flash-Next，包括逐层加载、量化和保存，3D MoE experts 拆分，PLE 跳过量化并以 BF16 流式回填，以及 MTP 权重以 BF16 原样透传。

本权重导出时对 msModelSlim 做了一处本地修改：PLE 回填时仅将浮点 tensor 转换为 BF16，整数和布尔 tensor 保持原 dtype 和数值，避免 `layer_multipliers`、`ngram_heads_offsets` 和 `ngram_heads_vocab_sizes` 从 `int64` 被误转为 BF16。

```python
# msmodelslim/model/qwen4_exp_flash_next/model_adapter.py
- if tensor.dtype != torch.bfloat16:
+ if tensor.dtype.is_floating_point and tensor.dtype != torch.bfloat16:
      tensor = tensor.to(torch.bfloat16)
```

```bash
git clone -b master-qwen38 https://gitcode.com/code_mingming/msmodelslim.git
git -C msmodelslim checkout a3664d45aef26c9ccd7fb4884a6c2b2c2ee1456a
bash msmodelslim/install.sh

MODEL_PATH=/path/to/Qwen3.8-Flash-Next
SAVE_PATH=/path/to/Qwen3.8-Flash-Next-w8a8-mxfp8-mtp
CONFIG_PATH=$PWD/msmodelslim/lab_practice/qwen4_exp_flash_next/qwen4_w8a8_mxfp.yaml

msmodelslim quant \
  --model_path "$MODEL_PATH" \
  --save_path "$SAVE_PATH" \
  --device npu \
  --model_type Qwen3.8-Flash-Next \
  --config_path "$CONFIG_PATH" \
  --trust_remote_code True
```

## 3. 精度测试结果

| 模型名 | 量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3.8-Flash-Next-w8a8-mxfp8-mtp | W8A8 MXFP8 | GPQA-Diamond | 未测试 | - |
