---
license: apache-2.0
tasks:
  - image-text-to-text
base_model:
  - Qwen/Qwen3.5-397B-A17B
frameworks: PyTorch
base_model_relation: quantized
---
# Qwen3.5-397B-A17B-w4a4-mxfp4

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3.5-397B-A17B |
| 原始模型链接  | [Qwen/Qwen3.5-397B-A17B](https://modelscope.cn/models/Qwen/Qwen3.5-397B-A17B) |
| msmodelslim commit id  | c02855d2b678ae846151cdb9c76d0f9adf175165 |
| 精度测试机型  | |
| 精度测试平台  |  |
| 版本  |  |
| 链接  |  |


## 2 量化方法：
```
msmodelslim quant \ 
    --model_path {浮点权重路径} \
    --save_path {量化权重路径} \
    --device npu \
    --model_type Qwen3.5-397B-A17B \
    --config_path {本地.yaml路径} \
    --trust_remote_code True
```


## 3 精度测试结果
| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
|  |  |  |  |  |

* 精度存在波动，建议多次测试。
