---
license: MIT License
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - ZhipuAI/GLM-5.1
base_model_relation: quantized
---
# GLM-5.1-w8a8c8-mxfp8

## 1. 基本信息
|         项目          |                             信息                             |
| :-------------------: | :----------------------------------------------------------: |
|      原始模型名       |                           GLM-5.1                            |
|     原始模型链接      | [ZhipuAI/GLM-5.1](https://www.modelscope.cn/models/ZhipuAI/GLM-5.1) |
| msmodelslim commit id |           c9e5ca1189bee079ce00e9fe70ee1d546cb8f2b2           |
|     精度测试机型      |                                                              |
|     精度测试平台      |                                                              |
|         版本          |                                                              |
|         链接          |                                                              |


## 2 量化方法：
```python3
msmodelslim quant \
	--model_path {权重路径} \ 
	--save_path {量化权重路径} \
	--device npu \
	--model_type GLM-5.1 \
	--config_path {yaml配置路径} \
	--trust_remote_code True \
```


## 3 精度测试结果
| 模型名 | 量化格式 | 数据集 | 测试精度 % | 官方精度 % |
| :----: | :------: | :----: | :--------: | :--------: |
|        |          |        |            |            |

* 精度存在波动，建议多次测试。