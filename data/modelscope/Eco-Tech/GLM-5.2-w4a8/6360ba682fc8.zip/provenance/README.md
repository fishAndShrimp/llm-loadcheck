# GLM-5.2-w4a8 量化模型

## 1. 基本信息

| 项目 | 信息 |
|------|------|
| 原始模型名 | GLM-5.2 |
| 原始模型链接 | https://www.modelscope.cn/models/ZhipuAI/GLM-5.2 |
| 精度测试机型 | Atlas A3 1台 |
| 精度测试平台 | docker vllm/vllm-ascend |
| vllm-ascend | https://docs.vllm.ai/projects/ascend/en/latest/tutorials/models/GLM5.2.html |

## 2. 量化脚本

### 2.1 安装 msmodelslim 工具
```bash
git clone https://gitcode.com/Ascend/msmodelslim.git
cd msmodelslim
git fetch https://gitcode.com/Ascend/msmodelslim.git +refs/merge-requests/669/head:pr_669
git checkout pr_669
bash install.sh
```

### 2.2 执行量化命令

```bash
msmodelslim quant \
   --model_path /mnt/weight/GLM-5.2 \
   --save_path /mnt/weight/GLM-5.2-W4A8 \
   --device npu:0 \
   --model_type GLM-5.2 \
   --quant_type w4a8 \
   --trust_remote_code True
```

