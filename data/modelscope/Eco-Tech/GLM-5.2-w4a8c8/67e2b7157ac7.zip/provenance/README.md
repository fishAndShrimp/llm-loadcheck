# GLM-5.2-w4a8c8 量化模型

## 1. 基本信息

| 项目 | 信息 |
|------|------|
| 原始模型名 | GLM-5.2 |
| 原始模型链接 | https://www.modelscope.cn/models/ZhipuAI/GLM-5.2 |
| 精度测试机型 | Atlas A3 1台 |
| 精度测试平台 | docker vllm/vllm-ascend |
| vllm-ascend | https://docs.vllm.ai/projects/ascend/en/latest/tutorials/models/GLM5.2.html |

| 量化方式 | Tag |
|------|------|
| 带mtp量化的w4a8c8权重 | master |
| 不带mtp量化的w4a8c8权重(mtp为bf16格式) | nomtpquant |

## 2. 量化脚本

### 2.1 安装 msmodelslim 工具
```bash
git clone https://gitcode.com/Ascend/msmodelslim.git
cd msmodelslim
git fetch https://gitcode.com/Ascend/msmodelslim.git +refs/merge-requests/669/head:pr_669
git checkout pr_669
bash install.sh
```

### 2.2 执行量化命令

```bash
msmodelslim quant \
   --model_path /mnt/weight/GLM-5.2 \
   --save_path /mnt/weight/GLM-5.2-W4A8C8 \
   --device npu:0 \
   --model_type GLM-5.2 \
   --quant_type w4a8c8 \
   --trust_remote_code True
```

## 3 精度测试结果


| 模型名 |  量化格式 | 数据集 | 测试精度 % |
|:------:|:------:|:------:|:------:|
| GLM-5.2 | w4a8c8 | AIME 2026 | 91.75 | 

