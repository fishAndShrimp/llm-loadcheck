---
license: MIT License
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - ZhipuAI/GLM-5
base_model_relation: quantized
---
