---
license: Apache License 2.0
frameworks: PyTorch
base_model_relation: quantized

base_model:
  - Qwen/Qwen3-30B-A3B
tasks:
  - text-generation
---
# Qwen3-30B-A3B-w8a8-QuaRot-310

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3-30B-A3B |
| 原始模型链接  | [Qwen/Qwen3-30B-A3B](https://huggingface.co/Qwen/Qwen3-30B-A3B) |
| msmodelslim commit id  | 6a860e4a7b48b4573a8aeeaa12123d2bbc9ec9b8 |
| msmodelslim 操作指引  | [Readme](https://gitcode.com/Ascend/msmodelslim/blob/master/example/Qwen/README.md) |
| 精度测试机型  | Atlas 300I DUO|
| 精度测试平台  | docker MindIE 镜像 |
| 版本  | MindIE 2.3.0 |


## 2 量化命令：
### 模型稀疏量化
```Shell
python3 quant_qwen_moe_w8a8.py --model_path {浮点权重路径} \
--save_path {W8A8量化权重路径} \
--anti_dataset ../common/qwen3-moe_anti_prompt_50.json \
--calib_dataset ../common/qwen3-moe_calib_prompt_50.json \
--trust_remote_code True \
--rot
```


## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 浮点精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3-30B-A3B-w8a8-QuaRot-310 | w8a8 | BoolQ |88.01 | 88.01 |
| Qwen3-30B-A3B-w8a8-QuaRot-310 | w8a8 | CEval |84.32 | 83.88 |
| Qwen3-30B-A3B-w8a8-QuaRot-310 | w8a8 | GSM8K |94.54 | 94.31 |
* 精度数据来自于非深度思考模式的推理结果
