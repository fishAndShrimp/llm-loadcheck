---
license: Apache License 2.0
tags: []
tasks:
- image-text-to-text
frameworks: PyTorch
base_model:
  - Qwen/Qwen3.8-27B
base_model_relation: quantized
---
# Qwen3.8-27B-w8a8-mxfp8

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3.8-27B |
| 原始模型链接  | [ Qwen/Qwen3.8-27B ](https://www.modelscope.cn/models/Qwen/Qwen3.8-27B) |
| msmodelslim 仓库 | https://gitcode.com/keith_wa/ModelSlim_joejoezhou_qwen38/tree/qwen3_8_27b_adapter |
| msmodelslim commit id | dddb8897abfc628fa43e8c601ff7da3a8ad34068 |


## 2 量化脚本：

```shell
pip install transformers==5.14.0

msmodelslim quant \
  --config_path docs/zh/knowledge_base/ptq/convert/qwen3_8_27b_fp8_to_mxfp8.yaml \
  --model_path weight/Qwen3.8-27B-FP8 \
  --save_path weight/Qwen3.8-27B-w8a8-mxfp8 \
  --device npu:0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15

```

## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3.8-27B-w8a8-mxfp8 | w8a8_mxfp8 | GPQA | 89.39 | 89.2 |

* 精度存在波动，建议多次测试。
