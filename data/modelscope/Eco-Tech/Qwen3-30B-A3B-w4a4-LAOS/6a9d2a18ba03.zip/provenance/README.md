---
license: Apache License 2.0
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - Qwen/Qwen3-30B-A3B
base_model_relation: quantized
---
# Qwen3-30B-A3B-w4a4-LAOS

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3-30B-A3B |
| 原始模型链接  | [Qwen/Qwen3-30B-A3B](https://huggingface.co/Qwen/Qwen3-30B-A3B) |
| 精度测试机型  | Atlas 800T A3 1台|
| 精度测试平台  | sglang |
| 版本  | sglang 0.5.9|
| 链接  | https://github.com/sgl-project/sglang/pull/18924 |


## 2 量化命令：

WIP

## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3-30B-A3B-w4a4-LAOS | w4a4 | gsm8k (5 shot) | 90.50 | 91.50 |