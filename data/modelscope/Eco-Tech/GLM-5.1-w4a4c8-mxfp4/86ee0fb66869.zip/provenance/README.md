---
license: MIT License
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - ZhipuAI/GLM-5.1
base_model_relation: quantized
---
# GLM-5.1-w4a4c8-mxfp4

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | GLM-5.1 |
| 原始模型链接  | [ ZhipuAI/GLM-5.1 ](https://www.modelscope.cn/models/ZhipuAI/GLM-5.1) |
| msmodelslim commit id | c02855d2b678ae846151cdb9c76d0f9adf175165 |
| 精度测试平台  |  |
| 版本  |  |
| 链接  |  |


## 2 量化脚本：

```shell
pip install transformers==5.4.0

export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

msmodelslim quant \
  --model_path /weights/GLM_51 \
  --save_path /GLM_51_w4a4c8_mxfp4 \
  --device npu:0,1,2,3,4,5,6,7 \
  --model_type GLM-5.1 \
  --config_path  ./glm51.yaml\
  --trust_remote_code True
```

glm51.yaml:
```yaml
apiversion: modelslim_v1
spec:
  process:
  - type: quarot
    export_extra_info: true
  - type: flex_smooth_quant
    enable_subgraph_type:
    - norm-linear
    - ov
    include:
    - '*'
  - type: linear_quant
    qconfig:
      act:
        scope: per_block
        dtype: mxfp8
        symmetric: true
        method: minmax
      weight:
        scope: per_block
        dtype: mxfp8
        symmetric: true
        method: minmax
    include:
    - '*self_attn*'
    exclude:
    - '*kv_b_proj'
    - '*wk'
    - '*weights_proj'
  - type: linear_quant
    qconfig:
      act:
        scope: per_block
        dtype: mxfp8
        symmetric: true
        method: minmax
      weight:
        scope: per_block
        dtype: mxfp8
        symmetric: true
        method: minmax
    include:
    - '*mlp*'
    exclude:
    - '*gate'
    - '*mlp.experts.*'
  - type: linear_quant
    qconfig:
      act:
        scope: per_block
        dtype: mxfp4
        symmetric: true
        method: minmax
      weight:
        scope: per_block
        dtype: mxfp4
        symmetric: true
        method: minmax
    include:
    - '*mlp.experts.*'
  dataset: qwen3_cot_w4a4.json
  save:
  - type: ascendv1_saver
    part_file_size: 4
metadata:
  config_id: glm_5_1_w4a4c8_mxfp4
  score: 90.0
  label:
    w_bit: 4
    a_bit: 4
    is_sparse: false
    kv_cache: true
  verified_model_types: []
  verified_tags:
    GLM-5.1:
    - - vLLM_Ascend
      - Atlas_350
```

## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|:------:|
|  |  |   |  |  |

* 精度存在波动，建议多次测试。