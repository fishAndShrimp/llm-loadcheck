---
license: Apache License 2.0
base_model:
  - Qwen/Qwen3-235B-A22B-Instruct-2507
base_model_relation: quantized
frameworks: PyTorch
tasks:
  - text-generation
---
