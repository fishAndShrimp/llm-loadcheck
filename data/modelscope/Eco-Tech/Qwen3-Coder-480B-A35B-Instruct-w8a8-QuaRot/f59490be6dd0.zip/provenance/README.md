---
license: Apache License 2.0
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - Qwen/Qwen3-Coder-480B-A35B-Instruct
base_model_relation: quantized
---
