---
base_model:
- ""
- Qwen/Qwen3.8-27B
frameworks:
- ""
license: Apache License 2.0
tags: []
tasks:
- image-text-to-text
base_model_relation: quantized
---
# Qwen3.8-27B-w8a8

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3.8-27B |
| 原始模型链接  | [ Qwen/Qwen3.8-27B ](https://www.modelscope.cn/models/Qwen/Qwen3.8-27B) |
| msmodelslim 仓库 | https://gitcode.com/keith_wa/ModelSlim_joejoezhou_qwen38/tree/qwen3_8_27b_adapter |
| msmodelslim commit id | 173fc3787b496d4ef2e1e995bbf17c19f65a2083 |


## 2 量化脚本：

```shell
pip install transformers==5.14.0

msmodelslim quant --model_type Qwen3.8-27B --quant_type w8a8 --model_path weight/Qwen3.8-27B --save_path weight/Qwen3.8-27B-w8a8 --device npu:0,1,2,3,4,5,6,7 --trust_remote_code True

```

## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3.8-27B-w8a8 | w8a8 | GPQA | 89.9 | 89.2 |

* 精度存在波动，建议多次测试。