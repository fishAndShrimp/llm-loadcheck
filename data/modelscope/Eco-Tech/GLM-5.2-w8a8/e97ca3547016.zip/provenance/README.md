# GLM-5.2-w8a8 量化模型

## 1. 基本信息

| 项目 | 信息 |
|------|------|
| 原始模型名 | GLM-5.2 |
| 原始模型链接 | https://www.modelscope.cn/models/ZhipuAI/GLM-5.2 |
| 精度测试机型 | Atlas A3 1台 |
| 精度测试平台 | docker vllm/vllm-ascend |
| vllm-ascend | https://docs.vllm.ai/projects/ascend/en/latest/tutorials/models/GLM5.2.html |

## 2. 量化脚本

### 2.1 安装 msmodelslim 工具
```bash
git clone https://gitcode.com/Ascend/msmodelslim.git
cd msmodelslim
git reset --hard 4cc63e7dae9af18f4767bf989fa40812b877294d
git checkout pr_669
bash install.sh
```

### 2.2 执行量化命令

```bash
msmodelslim quant \
  --model_path ${MODEL_PATH} \
  --save_path ${SAVE_PATH} \
   --device npu:0 \
   --model_type GLM-5.2 \
   --quant_type w4a8c8 \
   --trust_remote_code True
```

## 3 精度测试结果


| 模型名 |  量化格式 | 数据集 | 测试精度 % |
|:------:|:------:|:------:|:------:|
| GLM-5.2 | w8a8 | AIME 2026 |93.33 | 



