---
license: apache-2.0
---
### You are viewing the default Readme template as no detailed model-card was provided by the model’s contributors. You can access the model files in the "Files and versions" tab.
#### Model files may be downloaded with ModelScope SDK or through git clone directly.

Download with ModelScope’s Python SDK
```bash
#Install ModelScope
pip install modelscope
```
```python
#Download with ModelScope’s Python SDK
from modelscope import snapshot_download
model_dir = snapshot_download('Eco-Tech/Qwen3.5-397B-A17B-w8a8-mtp')
```
Download with Git clone
```
git clone https://modelers.cn/Eco-Tech/Qwen3.5-397B-A17B-w8a8-mtp.git
```

<p style="color: lightgrey;">If you are a contributor to this model, we invite you to promptly update the model card content according to <a href="https://www.modelscope.cn/docs/contribute/model-integration" style="color: lightgrey; text-decoration: underline;">the model contribution documentation</a>.</p>
