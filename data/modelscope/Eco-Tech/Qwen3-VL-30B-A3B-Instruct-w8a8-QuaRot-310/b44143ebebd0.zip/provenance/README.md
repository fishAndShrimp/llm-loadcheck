---
license: Apache License 2.0
tasks:
  - image-text-to-text
frameworks: PyTorch
base_model:
  - Qwen/Qwen3-VL-30B-A3B-Instruct
base_model_relation: quantized
---
# Qwen3-VL-30B-A3B-Instruct-w8a8-QuaRot-310

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3-VL-30B-A3B-Instruct |
| 原始模型链接  | [Qwen/Qwen3-VL-30B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-VL-30B-A3B-Instruct) |
| msmodelslim commit id  | d9b21712396ffb511af286fcb031a405bf4f01f1 |
| msmodelslim 操作指引  | [Readme](https://gitcode.com/Ascend/msit/blob/master/msmodelslim/example/multimodal_vlm/Qwen3-VL-MoE/README.md) |
| 精度测试机型  | Atlas 300I DUO|
| 精度测试平台  | docker MindIE 镜像 |
| 版本  | [MindIE v3.0.0.beta.1](https://quay.io/repository/ascend/mindie?tab=tags) |


## 2 量化命令：
```Shell
msmodelslim quant \
    --model_path /path/to/qwen3_vl_moe_float_weights \
    --save_path /path/to/qwen3_vl_moe_quantized_weights \
    --device npu \
    --model_type Qwen3-VL-30B-A3B \
    --quant_type w8a8 \
    --trust_remote_code True
cd msit/msmodelslim/example
python3 deq_scale_cast.py \
    --model_path /path/to/qwen3_vl_moe_quantized_weights
    --save_directory /path/to/qwen3_vl_moe_quantized_weights_used_on_310
```


## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 浮点精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3-VL-30B-A3B-Instruct-w8a8-QuaRot-310 | w8a8 | textvqa |81.28 | 81.12 |
