---
license: Apache License 2.0
tasks:
  - image-text-to-text
frameworks: PyTorch
base_model_relation: quantized
base_model:
  - Qwen/Qwen3-VL-32B-Instruct
---
# Qwen3-VL-32B-Instruct-w8a8sc-310-vllm

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Qwen3-VL-32B-Instruct |
| 原始模型链接  | [Qwen/Qwen3-VL-32B-Instruct](https://huggingface.co/Qwen/Qwen3-VL-32B-Instruct) |
| msmodelslim commit id  | d9b21712396ffb511af286fcb031a405bf4f01f1 |
| msmodelslim 操作指引  | [Readme](https://gitcode.com/Ascend/msit/blob/master/msmodelslim/example/multimodal_vlm/Qwen3-VL/README.md) |
| 精度测试机型  | Atlas 300I DUO|
| 精度测试平台  | docker vLLM 镜像 |
| 版本  | [vLLM 26.0.0.poc](https://github.com/vllm-project/vllm-ascend/issues/7394#issuecomment-4325488445) |


## 2 量化命令：
### 模型稀疏量化
```Shell
python3 quant_qwen3vl.py \
    --model_path /path/to/qwen3_vl_float_weights \
    --save_directory /path/to/qwen3_vl_quantized_weights \
    --w_bit 4 \
    --a_bit 8 \
    --device_type npu \
    --anti_method m2 \
    --is_lowbit True \
    --fraction 0.01 \
    --use_sigma True \
    --torch_dtype fp16 \
    --trust_remote_code True
```
### 模型压缩
使用vLLM模型压缩脚本[save_sharded_state_310.py](https://github.com/vllm-project/vllm-ascend/blob/main/examples/save_sharded_state_310.py)
```Shell
cd /usr/local/python3.11.10/lib/python3.11/site-packages/msmodelslim/pytorch/weight_compression/compress_graph/
# 编译weight_compression组件，其中${install_path}为CANN软件的安装目录。
bash build.sh ${install_path}/ascend-toolkit/latest
export LD_LIBRARY_PATH=/usr/local/python3.11.10/lib/:$LD_LIBRARY_PATH
python save_sharded_state_310.py \
    --model /path/to/qwen3_vl_quantized_weights \
    --tensor-parallel-size ${TP数} \
    --output /path/to/qwen3_vl_quantized_weights_used_on_310 \
    --enforce-eager \
    --dtype float16 \
    --quantization ascend \
    --max-model-len 16384 \
    --enable-compress \
    --compress-process-num 8
```


## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 浮点精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Qwen3-VL-32B-Instruct-w8a8sc-310-vllm | w8a8sc | textvqa |81.27 | 80.59 |

