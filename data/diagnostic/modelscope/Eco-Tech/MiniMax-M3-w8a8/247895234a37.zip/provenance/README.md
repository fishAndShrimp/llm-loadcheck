---
license: other
license_name: minimax-community
tasks:
  - image-text-to-text
frameworks: PyTorch
base_model:
  - MiniMax/MiniMax-M3
base_model_relation: quantized
---
# MiniMax-M3-w8a8

## 简介
MiniMax-m3 是 MiniMax 推出的新一代旗舰基础模型，定位为兼具超长上下文、Agent、Coding 和原生多模态能力的统一模型。模型采用自研 MiniMax Sparse Attention（MSA）架构，在支持百万级上下文的同时显著降低长上下文推理成本。

## 量化步骤：

### 环境准备
```shell
git clone https://gitcode.com/Ascend/msmodelslim.git
cd msmodelslim
git reset --hard 4cc63e7dae9af18f4767bf989fa40812b877294d
#打patch，相应的patch放在w8a8的权重路径中
git apply msmodelslim-suppont-minimax-m3.patch
# 安装 msmodelslim
bash install.sh
```

### 量化脚本

`MODEL_PATH` 处使用下载好的官方的bf16的权重路径
```shell
msmodelslim quant \
  --model_path ${MODEL_PATH} \
  --save_path ${SAVE_PATH} \
  --device npu \
  --model_type MiniMax-M3 \
  --quant_type w8a8 \
  --trust_remote_code True
```


## 3 精度测试结果
| 模型名  | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|
| MiniMax-M3-w8a8 | gsm8k | 96.89 | 97.19 |