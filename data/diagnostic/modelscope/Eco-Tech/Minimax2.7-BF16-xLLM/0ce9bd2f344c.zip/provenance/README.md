---
license: other
license_name: MiniMax-M2
license_link: https://huggingface.co/MiniMaxAI/MiniMax-M2.7/blob/main/LICENSE-MODEL
tasks:
  - text-generation
base_model:
  - MiniMaxAI/MiniMax-M2.7
base_model_relation: quantized
---
# MiniMax-M2.7-bf16

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | MiniMax-M2.7 |
| 原始模型链接  | [ MiniMaxAI/MiniMax-M2.7 ](https://huggingface.co/MiniMaxAI/MiniMax-M2.7) |
| 架构 | MiniMaxM2ForCausalLM |
| 原始精度 | FP8 (float8_e4m3fn, block_size=[128,128]) |
| 反量化精度 | BF16 |
| Hidden Size | 3072 |
| Layers | 62 |
| Attention Heads | 48 (KV Heads: 8) |
| Experts | 256 (per-token top-8) |
| Vocab Size | 200064 |
| Max Position | 196608 |
| RoPE Theta | 5000000 |
| 原始 FP8 大小 | ~215 GB |
| BF16 权重大小 | ~427 GB |
| 分片数 | 125 个 safetensors |

## 2. 反量化脚本
使用 [dequant_minimax_fp8.py](https://github.com/jd-opensource/xllm/blob/main/tools/dequant_minimax_fp8.py) 从原始 FP8 权重离线反量化为 BF16：
```shell
python dequant_minimax_fp8.py \
    --input-dir  /path/to/MiniMax-M2.7 \
    --output-dir /path/to/MiniMax-M2.7-bf16
```

脚本将 FP8 block-wise 权重乘以对应的 `weight_scale_inv` 反量化为 BF16，同时移除 `config.json` 中的 `quantization_config` 字段并更新 `torch_dtype` 为 `bfloat16`。
