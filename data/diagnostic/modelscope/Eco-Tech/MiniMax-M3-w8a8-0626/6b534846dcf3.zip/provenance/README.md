---
license: other
license_name: minimax-community
tasks:
  - image-text-to-text
frameworks: PyTorch
base_model:
  - MiniMax/MiniMax-M3
base_model_relation: quantized
---
# MiniMax-M3-w8a8

## 简介
MiniMax-m3 是 MiniMax 推出的新一代旗舰基础模型，定位为兼具超长上下文、Agent、Coding 和原生多模态能力的统一模型。模型采用自研 MiniMax Sparse Attention（MSA）架构，在支持百万级上下文的同时显著降低长上下文推理成本。

## 量化步骤：

### 环境准备
```shell
git clone --branch minimax_m3 https://gitcode.com/tanxiangyuu/msmodelslim.git
cd msmodelslim
# 安装 msmodelslim
bash install.sh
```
commit id: 559e88684e3dd2b02976586745141138bb172508

### 量化脚本

`MODEL_PATH` 处使用下载好的官方的bf16的权重路径
```shell
msmodelslim quant \
  --model_path ${MODEL_PATH} \
  --save_path ${SAVE_PATH} \
  --device npu \
  --model_type MiniMax-M3 \
  --quant_type w8a8 \
  --trust_remote_code True
```

### 量化配置差异

0626版本相比于0day版本以下变化：

- 新增 `iter_smooth` 离群值抑制：在 `linear_quant` 前增加 `type: iter_smooth`，配置为 `alpha: 0.5`、`scale_min: 1e-5`、`symmetric: True`，并只对 `norm-linear` 子图生效。
- 减少 qkv 回退：0day版本显式排除了第 55-59 层的 `self_attn.q_proj/k_proj/v_proj`，这些 qkv 线性层不做 W8A8 量化；0626版本的 `exclude` 不再包含这些具体 qkv 层，因此更多 attention qkv 层会进入 W8A8 量化。


## 3 精度测试结果
| 模型名  | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|
| MiniMax-M3-w8a8 | gsm8k | 96.89 | 97.19 |
