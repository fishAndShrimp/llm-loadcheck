---
license: other
tasks:
  - text-generation
frameworks: PyTorch
base_model:
  - moonshotai/Kimi-K2-Thinking
base_model_relation: quantized
---
# Kimi-K2-Thinking-W8A8-QuaRot

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | Kimi-K2-Thinking |
| 原始模型链接  | [moonshotai/Kimi-K2-Thinking](https://huggingface.co/moonshotai/Kimi-K2-Thinking) |
| msmodelslim PR  | https://gitcode.com/Ascend/msit/pull/4932 |
| msmodelslim commit id  | f6644e30f574a054a104279be4bbfaf8fae96d14 |
| 精度测试机型  | Atlas 800T A3 4台|
| 精度测试平台  | docker vllm-ascend 镜像 |
| 版本  | vllm-ascend 0.11.0.RC2 |
| 链接  | quay.io/ascend/vllm-ascend:v0.11.0rc2 |


## 2 量化命令：
```Shell
msmodelslim quant \
--model_path ${model_path} \
--save_path ${save_path} \
--device npu \
--model_type Kimi-K2-Thinking \
--quant_type w8a8 \
--trust_remote_code True
```


## 3 精度测试结果

| 模型名 |  量化格式 | 数据集 | 测试精度 % | 官方精度 % |
|:------:|:------:|:------:|:------:|:------:|
| Kimi-K2-Thinking-W8A8 | w8a8 | gsm8k_gen_reasoning | 96.66 | 96.27 |
| Kimi-k2-Thinking-W8A8 | w8a8 | ceval_gen_reasoning | 88.33 | 90.77 |
| Kimi-k2-Thinking-W8A8 | w8a8 | mmlu_gen_reasoning | 91.80 | 91.99 |



