---
license: MIT License
frameworks: PyTorch
base_model_relation: quantized

base_model:
  - GLM 4.7
tasks:
  - text-generation
---
# GLM 4.7

## 1. 基本信息
| 项目 | 信息 |
|:------:|:------:|
| 原始模型名  | GLM 4.7 |
| 原始模型链接  | [GLM 4.7](https://www.modelscope.cn/models/ZhipuAI/GLM-4.7) |
| msmodelslim 操作指引  | https://blog.csdn.net/qq_37368095/article/details/156429653 |
| 精度测试机型  | 800T A3|
| 版本  | vllm-ascend 0.13.0.rc1 |

## 3 精度测试结果


| 模型名 |  量化格式 | 数据集 | 测试精度 % |
|:------:|:------:|:------:|:------:|
| GLM-4.7 | w8a8 | AIME 2025 |96.67 | 
| GLM-4.7 | w8a8 | BFCL-v3-simple | 94 | 
